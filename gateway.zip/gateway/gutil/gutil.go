package gutil
