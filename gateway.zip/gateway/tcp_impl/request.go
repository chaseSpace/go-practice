package tcp_impl

import (
	"go-practice/gateway/tcp_iface"

	"golang.org/x/net/context"
)

type Request struct {
	conn               tcp_iface.IConnection //已经和客户端建立好的 链接
	tcp_iface.IMessage                       //客户端请求的数据
	ctx                context.Context
}

func (r *Request) GetConnection() tcp_iface.IConnection {
	return r.conn
}

func (r *Request) Ctx() context.Context {
	return r.ctx
}
